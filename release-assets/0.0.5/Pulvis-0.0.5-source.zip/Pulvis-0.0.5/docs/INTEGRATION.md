# Pulvis 0.0.5: CsModular Host Integration

This guide describes how this repository integrates the Grain Freeze, Grain Sample, and Grain Osc modules with the CsModular host. It follows the host architecture and module-contribution conventions while documenting the implementation in this plugin checkout.

For user-facing instructions, see the [English manual](../README.md). Localized user manuals remain at the repository root; technical documents in docs are English only.

## 1. Integration model

CsModular modules have a JavaScript definition for the editor and a Csound UDO wrapper for audio generation. The host loads module definitions from its library index, builds the patch from modules and cables, and asks CsoundGenerator to emit orchestra code.

The Pulvis library follows that model:

- modules/GrainFreeze.js and modules/GrainFreeze.txt — live-recording module; installed under public/libraries/pulvis/modules/.
- modules/GrainSample.js and modules/GrainSample.txt — WAV-backed module; installed under public/libraries/pulvis/modules/.
- modules/GrainOsc.js and modules/GrainOsc.txt — oscillator-backed module; installed under public/libraries/pulvis/modules/.
- _index.json and _meta.json — module and library metadata; installed under public/libraries/pulvis/.
- csound/GrainCore.txt — shared grain engine; installed as public/csound/modules/GrainCore.txt.
- examples/pulvis-demo.json — example host patch; installed as public/patches/pulvis-demo.json.
- integration/csmodular.patch — host-side loader, sample, UI, localization, and build integration; applied to the host checkout.

The JavaScript files describe controls, ports, and editor presentation. Grain scheduling and audio processing do not run in JavaScript or Rust.

Grain Osc provides separate Phase warp and Phase jitter controls. Phase warp changes the wave within each oscillator cycle; Phase jitter randomizes the starting phase of each grain. Both controls start at 0. Grain Osc and Grain Sample have no audio input or Mix control. Grain Freeze is the only module with an audio input and Wet mix control. Right-click a module and choose **About Pulvis** to view its version, copyright, and license.

## 2. Signal flow and host routing

The host's Voice layer runs in instr 1; its FX layer runs in instr 2. Patches connect module ports through the host's Zak cable buses. The plugin does not add another instrument or a private inter-module audio bus.

Each Pulvis wrapper:

1. Grain Freeze reads its audio input with Zak at the host's configured block size; Grain Sample and Grain Osc have no audio input.
2. Reads control-rate inputs with zkr.
3. Calls the shared CMGrainCoreExtended UDO.
4. Writes its left and right outputs to the Zak buses allocated by the host.

Grain Sample and Grain Osc have stereo outputs and no audio inputs. Grain Freeze is the only module with a mono audio input; it records that signal into its private live ring buffer and mixes the dry signal with the granular output. All outputs remain patchable through ordinary host cables; connect them to an output module such as Outs2 to reach the sound device.

The wrappers must keep Zak reads and writes at the host block size. Do not move Zak I/O into a local-block-size core: Zak buses are allocated by the host's orchestra.

## 3. Shared DSP and dependency loading

csound/GrainCore.txt is the single source of the plugin's shared grain algorithm. The three module .txt files are thin wrappers and declare the dependency:

    ;@ requires GrainCore.txt

The host integration resolves required UDO files from public/csound/modules/, orders dependencies before their callers, and includes a shared dependency once. Missing files and dependency cycles must be reported as generation errors. Sample-table declarations are emitted before the UDOs when a patch contains Grain Sample.

The core owns a 64-slot voice pool per module instance. It advances grain scheduling sample by sample, then renders each control block using audio-rate vector operations. A grain that starts partway through a block retains its sample offset, so its start and end remain sample-accurate. When all slots are active, new triggers are dropped; active grains are not stolen.

The plugin must implement scheduling, voice lifetime, table reads, interpolation, playback phase, windows, random state, overlap mixing, and live-ring-buffer behavior in its own Csound source. Do not call or wrap Csound's built-in granular opcodes, including partikkel, partikkelsync, grain, grain2, grain3, syncgrain, granule, diskgrain, fof, fof2, fog, sndwarp, sndwarpst, mincer, or temposcal.

The shared core renders active grains in audio-rate vectors within the host block. Module wrappers perform Zak I/O at the host block size.

## 4. WAV import path

Grain Sample uses the host's sample-import integration:

1. The user selects one of eight sample slots and chooses a WAV file from the module context menu.
2. JavaScript checks supported WAV metadata, retains the file bytes for the current app session, and transfers them to Csound's virtual file system.
3. The generator declares sample tables only when Grain Sample is present in the patch.
4. Csound's GEN01 loads the source and the granular core reads it during synthesis. JavaScript does not decode, resample, or process grain audio.

Current import limits are:

- One file: at most 256 MiB and 5 minutes.
- Per app session: at most 512 MiB of source files and 48,000,000 decoded mono frames.
- Sample rates: 8–192 kHz.
- Mono or stereo; stereo input uses the left channel.
- PCM 8/16/24/32-bit, IEEE float32/64, and standard WAVE_FORMAT_EXTENSIBLE.
- RF64, RIFX, and more than two channels are unsupported.

Sample bytes persist through Stop/Start and recompilation within the current app session. They are not embedded in patch JSON and are not restored after the app is closed or reloaded. Replacing a sample safely restarts the audio engine so an active voice cannot keep reading a replaced table. See the [user manual](../README.md) for the complete sample workflow and limitations.

## 5. Install

The plugin targets the CsModular 0.1.5 source layout. Run the installer from the plugin repository root:

    node scripts/install.mjs E:/paper/csmodular-main

For a host carrying the earlier WAV session integration, the source installer applies `integration/wav-session-compat.patch` and checks that the resulting integration matches the current patch. For a clean baseline it applies `integration/csmodular.patch`. It stages the payload, then copies the ready-to-use modules, metadata, manuals, license, shared core and demo patch into the host.

### Desktop application packages

Pulvis 0.0.5 ships as a Windows x64 setup EXE and a Linux amd64 Debian `.deb`. macOS builds and device acceptance are pending. The `.deb` declares GTK and WebKit as system dependencies instead of bundling those runtime libraries. The installer writes module files into the selected `libraries/pulvis` directory and writes `GrainCore.txt` into the sibling `csound/modules/` directory. On Debian, apt installs the Pulvis Installer application. Launch it to install or remove the plugin in the chosen host. Both desktop installers require the host integration to be present already.

The selected host must include the Pulvis-compatible loader, sample-import, and build integration. The desktop installer registers `pulvis` in `libraries/_index.json`; old `granular` registrations and folders are migrated. The command-line installer applies the integration to supported source checkouts. The desktop installer detects common host locations and provides a folder picker for source checkouts or custom paths. Its interface supports English, Simplified Chinese, and Russian and follows the system language unless a language is selected manually. The selected host directory must be writable by the installer.

The package version is shared by the library metadata, root package, Tauri configuration, Rust crate, localized manuals, and CI artifact names. `npm run package:smoke` checks those values, the installer resource manifest and the shared-core destination without compiling the native application.

## 6. Common integration issues

- **A required UDO is missing:** confirm that csound/GrainCore.txt was installed to public/csound/modules/GrainCore.txt, then recompile the patch.
- **A module does not appear in the library:** check that its entry in _index.json is stable or passable; release builds filter out development and broken modules.
- **A sample slot is silent:** empty slots produce silence. Re-import files after closing or reloading the app because samples are session data.
- **The module has no sound-device output:** route its Zak outputs through the patch to a host output module such as Outs2.

## 7. License

Copyright © 2026 Zhang Shengwei. Released under the MIT License; see [LICENSE](../LICENSE).
