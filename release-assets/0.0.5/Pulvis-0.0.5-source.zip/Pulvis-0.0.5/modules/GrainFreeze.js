export const GrainFreezeModule = {
    "type": "GrainFreeze",
    "displayName": "Pulvis Grain Freeze",
    "displayNameI18n": {
        "en": "Pulvis Grain Freeze",
        "zh": "微粒 · 颗粒冻结",
        "ru": "Пульвис · Гранулярная заморозка"
    },
    "category": "fx",
    "status": "passable",
    "gridHeight": 35,
    "originalName": "GrainFreeze",
    "defaultParams": [],
    "tooltip": "Records an 8 s live ring for granular playback. Freeze stops recording; Capture copies the current ring into a private snapshot table. Choose Live or Snapshot independently of Sample WAV slots. Reverse changes grain playback direction. Feedback (0–0.95) feeds wet grains back into recording and limits stored peaks to ±1; 0 is the clean linear default. Up to 64 grains at once.",
    "tooltipI18n": {
        "en": "Records an 8 s live ring for granular playback. Freeze stops recording; Capture copies the current ring into a private snapshot table. Choose Live or Snapshot independently of Sample WAV slots. Reverse changes grain playback direction. Feedback (0–0.95) feeds wet grains back into recording and limits stored peaks to ±1; 0 is the clean linear default. Up to 64 grains at once.",
        "zh": "录入 8 秒实时环形缓冲供颗粒播放。冻结会停止录音；“捕捉快照”把当前缓冲复制到 Freeze 私有表。实时／快照来源独立于 Sample 的 WAV 槽。反向会改变颗粒播放方向。反馈（0–0.95）把湿声颗粒回送录音，并将写入峰值限制在 ±1；默认 0 保持干净线性。最多同时 64 个颗粒。",
        "ru": "Записывает 8-секундный кольцевой буфер для гранул. «Стоп» останавливает запись; «Снимок» копирует буфер в отдельную таблицу Freeze. Источники «Вход/Снимок» не связаны со слотами WAV модуля Sample. «Назад» меняет направление гранул. Обратная связь (0–0,95) возвращает влажный сигнал в запись и ограничивает пики записи уровнем ±1; значение 0 сохраняет чистый линейный тракт. До 64 гранул одновременно."
    },
    "params": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18
    ],
    "inputs": [
        101,
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        112,
        113,
        115,
        116,
        117
    ],
    "outputs": [
        201,
        202
    ],
    "components": [
        {
            "componentType": "TextLabel",
            "id": "900",
            "x": 12,
            "y": 25,
            "text": "LIVE: connect audio first",
            "textI18n": {
                "en": "LIVE: connect audio first",
                "zh": "实时处理：先连接音频输入",
                "ru": "Вход: подключите звук"
            },
            "fontSize": 10
        },
        {
            "componentType": "TextLabel",
            "id": "901",
            "x": 12,
            "y": 40,
            "text": "Record → Freeze → Capture",
            "textI18n": {
                "en": "Record → Freeze → Capture",
                "zh": "录入 → 冻结 → 捕捉快照",
                "ru": "Запись → Стоп → Снимок"
            },
            "fontSize": 9
        },
        {
            "componentType": "TextLabel",
            "id": "910",
            "x": 12,
            "y": 64,
            "text": "1 · Record & freeze",
            "textI18n": {
                "en": "1 · Record & freeze",
                "zh": "1 · 录入与冻结",
                "ru": "1 · Запись и стоп"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "911",
            "x": 12,
            "y": 128,
            "text": "2 · Density & shape",
            "textI18n": {
                "en": "2 · Density & shape",
                "zh": "2 · 密度与塑形",
                "ru": "2 · Плотность и форма"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "912",
            "x": 12,
            "y": 192,
            "text": "2 · Shape & randomness",
            "textI18n": {
                "en": "2 · Shape & randomness",
                "zh": "2 · 颗粒塑形与随机",
                "ru": "2 · Форма и случайность"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "913",
            "x": 12,
            "y": 256,
            "text": "3 · Wet mix & output",
            "textI18n": {
                "en": "3 · Wet mix & output",
                "zh": "3 · 湿声混合与输出",
                "ru": "3 · Микс и выход"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "914",
            "x": 12,
            "y": 320,
            "text": "4 · Direction & pan",
            "textI18n": {
                "en": "4 · Direction & pan",
                "zh": "4 · 方向与声像",
                "ru": "4 · Направление и панорама"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "915",
            "x": 12,
            "y": 384,
            "text": "5 · Snapshot & feedback",
            "textI18n": {
                "en": "5 · Snapshot & feedback",
                "zh": "5 · 快照与反馈",
                "ru": "5 · Снимок и обратная связь"
            },
            "fontSize": 11
        },
        {
            "componentType": "Knob",
            "id": "1",
            "x": 12,
            "y": 164,
            "size": "medium",
            "min": 0,
            "max": 24,
            "defaultValue": 12,
            "csoundName": "Density"
        },
        {
            "componentType": "TextLabel",
            "id": "300",
            "x": 12,
            "y": 150,
            "text": "Grains/s",
            "textI18n": {
                "en": "Grains/s",
                "zh": "颗粒/秒",
                "ru": "Гранул/с"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "102",
            "x": 51,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Grains/s CV",
            "connectorNameI18n": {
                "en": "Grains/s CV",
                "zh": "颗粒/秒 调制输入",
                "ru": "Модуляция: Гранул/с"
            }
        },
        {
            "componentType": "Knob",
            "id": "2",
            "x": 94,
            "y": 164,
            "size": "medium",
            "min": 2,
            "max": 400,
            "defaultValue": 80,
            "csoundName": "Size"
        },
        {
            "componentType": "TextLabel",
            "id": "301",
            "x": 94,
            "y": 150,
            "text": "Size ms",
            "textI18n": {
                "en": "Size ms",
                "zh": "粒长（ms）",
                "ru": "Длина, мс"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "103",
            "x": 133,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Size ms CV",
            "connectorNameI18n": {
                "en": "Size ms CV",
                "zh": "粒长（ms） 调制输入",
                "ru": "Модуляция: Длина, мс"
            }
        },
        {
            "componentType": "Knob",
            "id": "3",
            "x": 94,
            "y": 100,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 32,
            "csoundName": "Position"
        },
        {
            "componentType": "TextLabel",
            "id": "302",
            "x": 94,
            "y": 86,
            "text": "Lookback",
            "textI18n": {
                "en": "Lookback",
                "zh": "回看位置",
                "ru": "В прошлое"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "104",
            "x": 133,
            "y": 103,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Lookback CV",
            "connectorNameI18n": {
                "en": "Lookback CV",
                "zh": "回看位置 调制输入",
                "ru": "Модуляция: В прошлое"
            }
        },
        {
            "componentType": "Knob",
            "id": "4",
            "x": 176,
            "y": 100,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 8,
            "csoundName": "PosJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "303",
            "x": 176,
            "y": 86,
            "text": "Lookback jitter",
            "textI18n": {
                "en": "Lookback jitter",
                "zh": "回看抖动",
                "ru": "Разброс назад"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "105",
            "x": 215,
            "y": 103,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Lookback jitter CV",
            "connectorNameI18n": {
                "en": "Lookback jitter CV",
                "zh": "回看抖动 调制输入",
                "ru": "Модуляция: Разброс назад"
            }
        },
        {
            "componentType": "Knob",
            "id": "5",
            "x": 12,
            "y": 228,
            "size": "medium",
            "min": -48,
            "max": 48,
            "defaultValue": 0,
            "csoundName": "Pitch"
        },
        {
            "componentType": "TextLabel",
            "id": "304",
            "x": 12,
            "y": 214,
            "text": "Pitch st",
            "textI18n": {
                "en": "Pitch st",
                "zh": "音高（半音）",
                "ru": "Высота, пт"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "106",
            "x": 51,
            "y": 231,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pitch st CV",
            "connectorNameI18n": {
                "en": "Pitch st CV",
                "zh": "音高（半音） 调制输入",
                "ru": "Модуляция: Высота, пт"
            }
        },
        {
            "componentType": "Knob",
            "id": "6",
            "x": 94,
            "y": 228,
            "size": "medium",
            "min": 0,
            "max": 24,
            "defaultValue": 0,
            "csoundName": "PitchJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "305",
            "x": 94,
            "y": 214,
            "text": "Pitch jitter",
            "textI18n": {
                "en": "Pitch jitter",
                "zh": "音高抖动（半音）",
                "ru": "Разброс выс."
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "107",
            "x": 133,
            "y": 231,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pitch jitter CV",
            "connectorNameI18n": {
                "en": "Pitch jitter CV",
                "zh": "音高抖动（半音） 调制输入",
                "ru": "Модуляция: Разброс выс."
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "7",
            "x": 176,
            "y": 170,
            "width": 57,
            "items": "Hann,Triangle,Blackman",
            "itemsI18n": {
                "en": "Hann,Triangle,Blackman",
                "zh": "汉宁窗,三角窗,布莱克曼窗",
                "ru": "Ханн,Треуг.,Блэкман"
            },
            "initialIndex": 0,
            "indexValue": true,
            "csoundName": "Window"
        },
        {
            "componentType": "TextLabel",
            "id": "306",
            "x": 176,
            "y": 150,
            "text": "Grain window",
            "textI18n": {
                "en": "Grain window",
                "zh": "颗粒包络",
                "ru": "Окно гранулы"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "108",
            "x": 242,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Grain window CV",
            "connectorNameI18n": {
                "en": "Grain window CV",
                "zh": "颗粒包络 调制输入",
                "ru": "Модуляция: Окно гранулы"
            }
        },
        {
            "componentType": "Knob",
            "id": "8",
            "x": 12,
            "y": 356,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 64,
            "csoundName": "Pan"
        },
        {
            "componentType": "TextLabel",
            "id": "307",
            "x": 12,
            "y": 342,
            "text": "Pan",
            "textI18n": {
                "en": "Pan",
                "zh": "声像",
                "ru": "Панорама"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "109",
            "x": 51,
            "y": 359,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pan CV",
            "connectorNameI18n": {
                "en": "Pan CV",
                "zh": "声像 调制输入",
                "ru": "Модуляция: Панорама"
            }
        },
        {
            "componentType": "Knob",
            "id": "9",
            "x": 94,
            "y": 292,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 64,
            "csoundName": "Spread"
        },
        {
            "componentType": "TextLabel",
            "id": "308",
            "x": 94,
            "y": 278,
            "text": "Pan spread",
            "textI18n": {
                "en": "Pan spread",
                "zh": "声像扩展",
                "ru": "Разброс пан."
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "110",
            "x": 133,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pan spread CV",
            "connectorNameI18n": {
                "en": "Pan spread CV",
                "zh": "声像扩展 调制输入",
                "ru": "Модуляция: Разброс пан."
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "10",
            "x": 12,
            "y": 106,
            "width": 57,
            "items": "Record,Freeze",
            "itemsI18n": {
                "en": "Record,Freeze",
                "zh": "录入,冻结",
                "ru": "Запись,Стоп"
            },
            "initialIndex": 0,
            "binaryThreshold": true,
            "csoundName": "Freeze"
        },
        {
            "componentType": "TextLabel",
            "id": "309",
            "x": 12,
            "y": 86,
            "text": "Freeze",
            "textI18n": {
                "en": "Freeze",
                "zh": "冻结",
                "ru": "Заморозка"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "111",
            "x": 78,
            "y": 103,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Freeze CV",
            "connectorNameI18n": {
                "en": "Freeze CV",
                "zh": "冻结 调制输入",
                "ru": "Модуляция: Заморозка"
            }
        },
        {
            "componentType": "Knob",
            "id": "11",
            "x": 12,
            "y": 292,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 127,
            "csoundName": "Mix"
        },
        {
            "componentType": "TextLabel",
            "id": "310",
            "x": 12,
            "y": 278,
            "text": "Wet mix",
            "textI18n": {
                "en": "Wet mix",
                "zh": "干湿比",
                "ru": "Микс"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "112",
            "x": 51,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Wet mix CV",
            "connectorNameI18n": {
                "en": "Wet mix CV",
                "zh": "干湿比 调制输入",
                "ru": "Модуляция: Микс"
            }
        },
        {
            "componentType": "Knob",
            "id": "12",
            "x": 176,
            "y": 292,
            "size": "medium",
            "min": -24,
            "max": 12,
            "defaultValue": -3,
            "csoundName": "Level"
        },
        {
            "componentType": "TextLabel",
            "id": "311",
            "x": 176,
            "y": 278,
            "text": "Output dB",
            "textI18n": {
                "en": "Output dB",
                "zh": "输出电平 dB",
                "ru": "Уровень, дБ"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "113",
            "x": 215,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Output dB CV",
            "connectorNameI18n": {
                "en": "Output dB CV",
                "zh": "输出电平 dB 调制输入",
                "ru": "Модуляция: Уровень, дБ"
            }
        },
        {
            "componentType": "Knob",
            "id": "13",
            "x": 176,
            "y": 228,
            "size": "medium",
            "min": 0,
            "max": 65534,
            "defaultValue": 1,
            "csoundName": "Seed"
        },
        {
            "componentType": "TextLabel",
            "id": "312",
            "x": 176,
            "y": 214,
            "text": "Random seed",
            "textI18n": {
                "en": "Random seed",
                "zh": "随机种子",
                "ru": "Случ. зерно"
            },
            "fontSize": 9
        },
        {
            "componentType": "Knob",
            "id": "14",
            "x": 94,
            "y": 356,
            "size": "medium",
            "min": 0,
            "max": 100,
            "defaultValue": 0,
            "csoundName": "TimeJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "313",
            "x": 94,
            "y": 342,
            "text": "Time scatter %",
            "textI18n": {
                "en": "Time scatter %",
                "zh": "时间散布 %",
                "ru": "Разброс времени"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "115",
            "x": 133,
            "y": 359,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Time scatter % CV",
            "connectorNameI18n": {
                "en": "Time scatter % CV",
                "zh": "时间散布 % 调制输入",
                "ru": "Модуляция: Разброс времени"
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "15",
            "x": 176,
            "y": 362,
            "width": 57,
            "items": "Forward,Reverse",
            "itemsI18n": {
                "en": "Forward,Reverse",
                "zh": "正向,反向",
                "ru": "Вперёд,Назад"
            },
            "initialIndex": 0,
            "binaryThreshold": true,
            "csoundName": "Reverse"
        },
        {
            "componentType": "TextLabel",
            "id": "314",
            "x": 176,
            "y": 342,
            "text": "Direction",
            "textI18n": {
                "en": "Direction",
                "zh": "播放方向",
                "ru": "Направление"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "116",
            "x": 242,
            "y": 359,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Direction CV",
            "connectorNameI18n": {
                "en": "Direction CV",
                "zh": "播放方向 调制输入",
                "ru": "Модуляция: Направление"
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "16",
            "x": 12,
            "y": 426,
            "width": 57,
            "items": "Live,Snapshot",
            "itemsI18n": {
                "en": "Live,Snapshot",
                "zh": "实时,快照",
                "ru": "Вход,Снимок"
            },
            "initialIndex": 0,
            "binaryThreshold": true,
            "csoundName": "Source"
        },
        {
            "componentType": "TextLabel",
            "id": "315",
            "x": 12,
            "y": 406,
            "text": "Playback source",
            "textI18n": {
                "en": "Playback source",
                "zh": "播放来源",
                "ru": "Источник"
            },
            "fontSize": 9
        },
        {
            "componentType": "Knob",
            "id": "17",
            "x": 94,
            "y": 420,
            "size": "medium",
            "min": 0,
            "max": 0.95,
            "defaultValue": 0,
            "csoundName": "Feedback"
        },
        {
            "componentType": "TextLabel",
            "id": "316",
            "x": 94,
            "y": 406,
            "text": "Feedback",
            "textI18n": {
                "en": "Feedback",
                "zh": "反馈",
                "ru": "Обратная связь"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "117",
            "x": 133,
            "y": 423,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Feedback CV",
            "connectorNameI18n": {
                "en": "Feedback CV",
                "zh": "反馈 调制输入",
                "ru": "Модуляция: Обратная связь"
            }
        },
        {
            "componentType": "ButtonText",
            "id": "18",
            "x": 176,
            "y": 424,
            "width": 62,
            "height": 17,
            "text": "Capture snapshot",
            "textI18n": {
                "en": "Capture snapshot",
                "zh": "捕捉快照",
                "ru": "Сохранить снимок"
            },
            "initialState": false,
            "mode": "momentary",
            "returnState": false,
            "csoundName": "Capture"
        },
        {
            "componentType": "Input",
            "id": "101",
            "x": 18,
            "y": 499,
            "jackType": "audio",
            "bandwidth": "static",
            "ConnectorName": "Audio in",
            "connectorNameI18n": {
                "en": "Audio in",
                "zh": "音频输入",
                "ru": "Аудиовход"
            }
        },
        {
            "componentType": "TextLabel",
            "id": "601",
            "x": 15,
            "y": 480,
            "text": "Audio in",
            "textI18n": {
                "en": "Audio in",
                "zh": "音频输入",
                "ru": "Аудиовход"
            },
            "fontSize": 10
        },
        {
            "componentType": "Output",
            "id": "201",
            "x": 168,
            "y": 499,
            "jackType": "audio",
            "bandwidth": "static",
            "ConnectorName": "L",
            "connectorNameI18n": {
                "en": "L",
                "zh": "左",
                "ru": "Л"
            }
        },
        {
            "componentType": "TextLabel",
            "id": "701",
            "x": 165,
            "y": 480,
            "text": "L",
            "textI18n": {
                "en": "L",
                "zh": "左",
                "ru": "Л"
            },
            "fontSize": 10
        },
        {
            "componentType": "Output",
            "id": "202",
            "x": 216,
            "y": 499,
            "jackType": "audio",
            "bandwidth": "static",
            "ConnectorName": "R",
            "connectorNameI18n": {
                "en": "R",
                "zh": "右",
                "ru": "П"
            }
        },
        {
            "componentType": "TextLabel",
            "id": "702",
            "x": 213,
            "y": 480,
            "text": "R",
            "textI18n": {
                "en": "R",
                "zh": "右",
                "ru": "П"
            },
            "fontSize": 10
        }
    ]
};
