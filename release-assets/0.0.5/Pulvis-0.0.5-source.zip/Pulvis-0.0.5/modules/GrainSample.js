export const GrainSampleModule = {
    "type": "GrainSample",
    "displayName": "Pulvis Grain Sample",
    "displayNameI18n": {
        "en": "Pulvis Grain Sample",
        "zh": "微粒 · 颗粒采样",
        "ru": "Пульвис · Гранулярный сэмпл"
    },
    "category": "sample",
    "status": "passable",
    "gridHeight": 35,
    "originalName": "GrainSample",
    "defaultParams": [],
    "tooltip": "Standalone WAV source. Right-click to load a WAV into the selected slot; an empty slot is silent. Scan moves through the file (percent per second; Hold pauses it). Reverse plays grains backward. Timing scatter varies trigger times independently from Position jitter while keeping mean density. Up to 64 grains at once. Small jacks beside knobs add modulation.",
    "tooltipI18n": {
        "en": "Standalone WAV source. Right-click to load a WAV into the selected slot; an empty slot is silent. Scan moves through the file (percent per second; Hold pauses it). Reverse plays grains backward. Timing scatter varies trigger times independently from Position jitter while keeping mean density. Up to 64 grains at once. Small jacks beside knobs add modulation.",
        "zh": "独立 WAV 声源，无需音频输入。右键导入当前槽的 WAV；空槽无声。“扫描”让位置在文件中移动，锁定会暂停。反向会倒放颗粒。时间散布独立于位置抖动改变触发时刻，同时保持平均粒速。最多同时 64 个颗粒；可调制控件旁的小插孔可叠加控制信号。",
        "ru": "Самостоятельный WAV-источник, аудиовход не нужен. ПКМ — загрузить файл в выбранный слот; пустой слот молчит. «Скан.» двигает позицию по файлу (% в секунду; фиксация останавливает ход). Обратное направление проигрывает гранулы назад. Разброс времени отдельно от позиции меняет запуски, сохраняя среднюю плотность. До 64 гранул. Малые гнёзда принимают CV."
    },
    "params": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        12,
        13,
        14,
        15,
        16,
        17
    ],
    "inputs": [
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        113,
        115,
        116
    ],
    "outputs": [
        201,
        202
    ],
    "components": [
        {
            "componentType": "TextLabel",
            "id": "900",
            "x": 12,
            "y": 25,
            "text": "FILE: right-click → Load WAV",
            "textI18n": {
                "en": "FILE: right-click → Load WAV",
                "zh": "文件播放：右键 → 导入 WAV",
                "ru": "Файл: ПКМ → загрузить WAV"
            },
            "fontSize": 10
        },
        {
            "componentType": "TextLabel",
            "id": "901",
            "x": 12,
            "y": 40,
            "text": "Select a slot, then load WAV",
            "textI18n": {
                "en": "Select a slot, then load WAV",
                "zh": "先选槽，再导入 WAV",
                "ru": "Выберите слот и загрузите WAV"
            },
            "fontSize": 9
        },
        {
            "componentType": "TextLabel",
            "id": "910",
            "x": 12,
            "y": 64,
            "text": "1 · WAV source",
            "textI18n": {
                "en": "1 · WAV source",
                "zh": "1 · WAV 文件声源",
                "ru": "1 · Источник WAV"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "911",
            "x": 12,
            "y": 128,
            "text": "2 · Shape & randomness",
            "textI18n": {
                "en": "2 · Shape & randomness",
                "zh": "2 · 颗粒塑形与随机",
                "ru": "2 · Форма и случайность"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "912",
            "x": 12,
            "y": 256,
            "text": "3 · Stereo output",
            "textI18n": {
                "en": "3 · Stereo output",
                "zh": "3 · 立体声输出",
                "ru": "3 · Стереовыход"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "913",
            "x": 12,
            "y": 320,
            "text": "Advanced · direction",
            "textI18n": {
                "en": "Advanced · direction",
                "zh": "进阶 · 方向",
                "ru": "Дополнительно · направление"
            },
            "fontSize": 11
        },
        {
            "componentType": "TextLabel",
            "id": "914",
            "x": 12,
            "y": 384,
            "text": "4 · Timing",
            "textI18n": {
                "en": "4 · Timing",
                "zh": "4 · 时序",
                "ru": "4 · Тайминг"
            },
            "fontSize": 11
        },
        {
            "componentType": "Knob",
            "id": "1",
            "x": 12,
            "y": 164,
            "size": "medium",
            "min": 0,
            "max": 24,
            "defaultValue": 12,
            "csoundName": "Density"
        },
        {
            "componentType": "TextLabel",
            "id": "300",
            "x": 12,
            "y": 150,
            "text": "Grains/s",
            "textI18n": {
                "en": "Grains/s",
                "zh": "颗粒/秒",
                "ru": "Гранул/с"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "102",
            "x": 51,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Grains/s CV",
            "connectorNameI18n": {
                "en": "Grains/s CV",
                "zh": "颗粒/秒 调制输入",
                "ru": "Модуляция: Гранул/с"
            }
        },
        {
            "componentType": "Knob",
            "id": "2",
            "x": 94,
            "y": 164,
            "size": "medium",
            "min": 2,
            "max": 400,
            "defaultValue": 80,
            "csoundName": "Size"
        },
        {
            "componentType": "TextLabel",
            "id": "301",
            "x": 94,
            "y": 150,
            "text": "Size ms",
            "textI18n": {
                "en": "Size ms",
                "zh": "粒长（ms）",
                "ru": "Длина, мс"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "103",
            "x": 133,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Size ms CV",
            "connectorNameI18n": {
                "en": "Size ms CV",
                "zh": "粒长（ms） 调制输入",
                "ru": "Модуляция: Длина, мс"
            }
        },
        {
            "componentType": "Knob",
            "id": "3",
            "x": 94,
            "y": 100,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 32,
            "csoundName": "Position"
        },
        {
            "componentType": "TextLabel",
            "id": "302",
            "x": 94,
            "y": 86,
            "text": "Sample position",
            "textI18n": {
                "en": "Sample position",
                "zh": "采样位置",
                "ru": "Позиция файла"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "104",
            "x": 133,
            "y": 103,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Sample position CV",
            "connectorNameI18n": {
                "en": "Sample position CV",
                "zh": "采样位置 调制输入",
                "ru": "Модуляция: Позиция файла"
            }
        },
        {
            "componentType": "Knob",
            "id": "4",
            "x": 94,
            "y": 228,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 8,
            "csoundName": "PosJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "303",
            "x": 94,
            "y": 214,
            "text": "Position jitter",
            "textI18n": {
                "en": "Position jitter",
                "zh": "位置抖动",
                "ru": "Разброс поз."
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "105",
            "x": 133,
            "y": 231,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Position jitter CV",
            "connectorNameI18n": {
                "en": "Position jitter CV",
                "zh": "位置抖动 调制输入",
                "ru": "Модуляция: Разброс поз."
            }
        },
        {
            "componentType": "Knob",
            "id": "5",
            "x": 176,
            "y": 164,
            "size": "medium",
            "min": -48,
            "max": 48,
            "defaultValue": 0,
            "csoundName": "Pitch"
        },
        {
            "componentType": "TextLabel",
            "id": "304",
            "x": 176,
            "y": 150,
            "text": "Pitch st",
            "textI18n": {
                "en": "Pitch st",
                "zh": "音高（半音）",
                "ru": "Высота, пт"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "106",
            "x": 215,
            "y": 167,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pitch st CV",
            "connectorNameI18n": {
                "en": "Pitch st CV",
                "zh": "音高（半音） 调制输入",
                "ru": "Модуляция: Высота, пт"
            }
        },
        {
            "componentType": "Knob",
            "id": "6",
            "x": 176,
            "y": 228,
            "size": "medium",
            "min": 0,
            "max": 24,
            "defaultValue": 0,
            "csoundName": "PitchJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "305",
            "x": 176,
            "y": 214,
            "text": "Pitch jitter",
            "textI18n": {
                "en": "Pitch jitter",
                "zh": "音高抖动（半音）",
                "ru": "Разброс выс."
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "107",
            "x": 215,
            "y": 231,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pitch jitter CV",
            "connectorNameI18n": {
                "en": "Pitch jitter CV",
                "zh": "音高抖动（半音） 调制输入",
                "ru": "Модуляция: Разброс выс."
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "7",
            "x": 12,
            "y": 234,
            "width": 57,
            "items": "Hann,Triangle,Blackman",
            "itemsI18n": {
                "en": "Hann,Triangle,Blackman",
                "zh": "汉宁窗,三角窗,布莱克曼窗",
                "ru": "Ханн,Треуг.,Блэкман"
            },
            "initialIndex": 0,
            "indexValue": true,
            "csoundName": "Window"
        },
        {
            "componentType": "TextLabel",
            "id": "306",
            "x": 12,
            "y": 214,
            "text": "Grain window",
            "textI18n": {
                "en": "Grain window",
                "zh": "颗粒包络",
                "ru": "Окно гранулы"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "108",
            "x": 78,
            "y": 231,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Grain window CV",
            "connectorNameI18n": {
                "en": "Grain window CV",
                "zh": "颗粒包络 调制输入",
                "ru": "Модуляция: Окно гранулы"
            }
        },
        {
            "componentType": "Knob",
            "id": "8",
            "x": 12,
            "y": 292,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 64,
            "csoundName": "Pan"
        },
        {
            "componentType": "TextLabel",
            "id": "307",
            "x": 12,
            "y": 278,
            "text": "Pan",
            "textI18n": {
                "en": "Pan",
                "zh": "声像",
                "ru": "Панорама"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "109",
            "x": 51,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pan CV",
            "connectorNameI18n": {
                "en": "Pan CV",
                "zh": "声像 调制输入",
                "ru": "Модуляция: Панорама"
            }
        },
        {
            "componentType": "Knob",
            "id": "9",
            "x": 94,
            "y": 292,
            "size": "medium",
            "min": 0,
            "max": 127,
            "defaultValue": 64,
            "csoundName": "Spread"
        },
        {
            "componentType": "TextLabel",
            "id": "308",
            "x": 94,
            "y": 278,
            "text": "Pan spread",
            "textI18n": {
                "en": "Pan spread",
                "zh": "声像扩展",
                "ru": "Разброс пан."
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "110",
            "x": 133,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Pan spread CV",
            "connectorNameI18n": {
                "en": "Pan spread CV",
                "zh": "声像扩展 调制输入",
                "ru": "Модуляция: Разброс пан."
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "10",
            "x": 12,
            "y": 362,
            "width": 57,
            "items": "Follow,Hold",
            "itemsI18n": {
                "en": "Follow,Hold",
                "zh": "跟随,锁定",
                "ru": "Следить,Фикс."
            },
            "initialIndex": 0,
            "binaryThreshold": true,
            "csoundName": "Freeze"
        },
        {
            "componentType": "TextLabel",
            "id": "309",
            "x": 12,
            "y": 342,
            "text": "Hold position",
            "textI18n": {
                "en": "Hold position",
                "zh": "锁定位置",
                "ru": "Фикс. позицию"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "111",
            "x": 78,
            "y": 359,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Hold position CV",
            "connectorNameI18n": {
                "en": "Hold position CV",
                "zh": "锁定位置 调制输入",
                "ru": "Модуляция: Фикс. позицию"
            }
        },
        {
            "componentType": "Knob",
            "id": "12",
            "x": 176,
            "y": 292,
            "size": "medium",
            "min": -24,
            "max": 12,
            "defaultValue": -12,
            "csoundName": "Level"
        },
        {
            "componentType": "TextLabel",
            "id": "311",
            "x": 176,
            "y": 278,
            "text": "Output dB",
            "textI18n": {
                "en": "Output dB",
                "zh": "输出电平 dB",
                "ru": "Уровень, дБ"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "113",
            "x": 215,
            "y": 295,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Output dB CV",
            "connectorNameI18n": {
                "en": "Output dB CV",
                "zh": "输出电平 dB 调制输入",
                "ru": "Модуляция: Уровень, дБ"
            }
        },
        {
            "componentType": "Knob",
            "id": "13",
            "x": 176,
            "y": 356,
            "size": "medium",
            "min": 0,
            "max": 65534,
            "defaultValue": 1,
            "csoundName": "Seed"
        },
        {
            "componentType": "TextLabel",
            "id": "312",
            "x": 176,
            "y": 342,
            "text": "Random seed",
            "textI18n": {
                "en": "Random seed",
                "zh": "随机种子",
                "ru": "Случ. зерно"
            },
            "fontSize": 9
        },
        {
            "componentType": "Knob",
            "id": "14",
            "x": 12,
            "y": 100,
            "size": "medium",
            "min": 1,
            "max": 8,
            "defaultValue": 1,
            "csoundName": "Slot"
        },
        {
            "componentType": "TextLabel",
            "id": "313",
            "x": 12,
            "y": 86,
            "text": "Sample slot",
            "textI18n": {
                "en": "Sample slot",
                "zh": "采样槽",
                "ru": "Слот сэмпла"
            },
            "fontSize": 9
        },
        {
            "componentType": "Knob",
            "id": "15",
            "x": 176,
            "y": 100,
            "size": "medium",
            "min": -100,
            "max": 100,
            "defaultValue": 0,
            "csoundName": "Scan"
        },
        {
            "componentType": "TextLabel",
            "id": "314",
            "x": 176,
            "y": 86,
            "text": "Scan %/s",
            "textI18n": {
                "en": "Scan %/s",
                "zh": "扫描 %/秒",
                "ru": "Скан. %/с"
            },
            "fontSize": 9
        },
        {
            "componentType": "Knob",
            "id": "16",
            "x": 12,
            "y": 420,
            "size": "medium",
            "min": 0,
            "max": 100,
            "defaultValue": 0,
            "csoundName": "TimeJitter"
        },
        {
            "componentType": "TextLabel",
            "id": "315",
            "x": 12,
            "y": 406,
            "text": "Time scatter %",
            "textI18n": {
                "en": "Time scatter %",
                "zh": "时间散布 %",
                "ru": "Разброс времени"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "115",
            "x": 51,
            "y": 423,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Time scatter % CV",
            "connectorNameI18n": {
                "en": "Time scatter % CV",
                "zh": "时间散布 % 调制输入",
                "ru": "Модуляция: Разброс времени"
            }
        },
        {
            "componentType": "ButtonIncDec",
            "id": "17",
            "x": 94,
            "y": 362,
            "width": 57,
            "items": "Forward,Reverse",
            "itemsI18n": {
                "en": "Forward,Reverse",
                "zh": "正向,反向",
                "ru": "Вперёд,Назад"
            },
            "initialIndex": 0,
            "binaryThreshold": true,
            "csoundName": "Reverse"
        },
        {
            "componentType": "TextLabel",
            "id": "316",
            "x": 94,
            "y": 342,
            "text": "Direction",
            "textI18n": {
                "en": "Direction",
                "zh": "播放方向",
                "ru": "Направление"
            },
            "fontSize": 9
        },
        {
            "componentType": "Input",
            "id": "116",
            "x": 160,
            "y": 359,
            "jackType": "control",
            "bandwidth": "static",
            "ConnectorName": "Direction CV",
            "connectorNameI18n": {
                "en": "Direction CV",
                "zh": "播放方向 调制输入",
                "ru": "Модуляция: Направление"
            }
        },
        {
            "componentType": "Output",
            "id": "201",
            "x": 168,
            "y": 499,
            "jackType": "audio",
            "bandwidth": "static",
            "ConnectorName": "L",
            "connectorNameI18n": {
                "en": "L",
                "zh": "左",
                "ru": "Л"
            }
        },
        {
            "componentType": "TextLabel",
            "id": "701",
            "x": 165,
            "y": 480,
            "text": "L",
            "textI18n": {
                "en": "L",
                "zh": "左",
                "ru": "Л"
            },
            "fontSize": 10
        },
        {
            "componentType": "Output",
            "id": "202",
            "x": 216,
            "y": 499,
            "jackType": "audio",
            "bandwidth": "static",
            "ConnectorName": "R",
            "connectorNameI18n": {
                "en": "R",
                "zh": "右",
                "ru": "П"
            }
        },
        {
            "componentType": "TextLabel",
            "id": "702",
            "x": 213,
            "y": 480,
            "text": "R",
            "textI18n": {
                "en": "R",
                "zh": "右",
                "ru": "П"
            },
            "fontSize": 10
        }
    ]
};
