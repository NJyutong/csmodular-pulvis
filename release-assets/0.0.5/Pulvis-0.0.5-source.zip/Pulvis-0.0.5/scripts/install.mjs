// Install into a compatible source checkout. Publish the host registration last.
import { lstat, mkdir, mkdtemp, readFile, rename, rm, rmdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const host = resolve(process.argv[2] || process.env.CSMODULAR_HOST_ROOT || resolve(root, '../csmodular-main'));
const patch = resolve(root, 'integration/csmodular.patch');
const compatibilityUpdate = resolve(root, 'integration/wav-session-compat.patch');
const git = (args, file = patch) => execFileSync('git', ['-c', `safe.directory=${host.replaceAll('\\', '/')}`, 'apply', ...args, file], { cwd: host, stdio: 'pipe' });
async function stat(path) {
    try { return await lstat(path); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
}
async function directory(path) {
    const info = await stat(path);
    if (info && !info.isDirectory()) throw new Error(`Expected a directory: ${path}`);
    return !!info;
}

const libraries = join(host, 'public/libraries');
const target = join(libraries, 'pulvis');
const legacy = join(libraries, 'granular');
const lock = join(host, '.pulvis-install-lock');
await mkdir(lock);
let staging;
let applied;
let migrated = false;
const undo = [];
const created = [];
let preserveBackup = false;
try {
    let nextPatch;
    try { git(['--reverse', '--check']); }
    catch {
        try { git(['--check']); nextPatch = patch; }
        catch (error) {
            try { git(['--check'], compatibilityUpdate); nextPatch = compatibilityUpdate; }
            catch { throw new Error(`Host integration does not match this checkout. Review integration/csmodular.patch.\n${error.stderr}`); }
        }
    }
    await directory(join(host, 'public'));
    await directory(libraries);
    const indexPath = join(libraries, '_index.json');
    const index = JSON.parse(await readFile(indexPath, 'utf8'));
    if (!Array.isArray(index.libraries)) throw new Error('Host library index has no libraries array.');
    const hasTarget = await directory(target);
    const hasLegacy = await directory(legacy);
    const migrate = !hasTarget && hasLegacy;
    if (!hasTarget || !hasLegacy) index.libraries = index.libraries.map(name => name === 'granular' ? 'pulvis' : name);
    index.libraries = index.libraries.filter((name, i, all) => name !== 'pulvis' || all.indexOf(name) === i);
    if (!index.libraries.includes('pulvis')) index.libraries.push('pulvis');

    const files = new Map();
    const modules = JSON.parse(await readFile(join(root, '_index.json'), 'utf8'));
    const ids = new Set(modules.modules.map(item => item.name));
    for (const id of ids) for (const ext of ['js', 'txt']) {
        const path = `modules/${id}.${ext}`;
        files.set(join(target, path), await readFile(join(root, path)));
    }
    const oldIndex = join(migrate ? legacy : target, '_index.json');
    let merged = modules;
    if (await stat(oldIndex)) {
        merged = JSON.parse(await readFile(oldIndex, 'utf8'));
        if (!Array.isArray(merged.modules)) throw new Error('Invalid module index.');
        merged.modules = [...merged.modules.filter(m => !ids.has(typeof m === 'string' ? m : m?.name)), ...modules.modules];
    }
    files.set(join(target, '_index.json'), JSON.stringify(merged, null, 2) + '\n');
    for (const path of ['_meta.json', 'README.md', 'README.zh-CN.md', 'README.ru.md', 'SOURCES.md', 'LICENSE', 'assets/pulvis-icon.png']) {
        files.set(join(target, path), await readFile(join(root, path)));
    }
    files.set(join(host, 'public/csound/modules/GrainCore.txt'), await readFile(join(root, 'csound/GrainCore.txt')));
    files.set(join(host, 'public/patches/pulvis-demo.json'), await readFile(join(root, 'examples/pulvis-demo.json')));
    files.set(indexPath, JSON.stringify(index, null, 2) + '\n');
    staging = await mkdtemp(join(host, '.pulvis-stage-'));
    let n = 0;
    for (const contents of files.values()) await writeFile(join(staging, String(n++)), contents);
    if (nextPatch) {
        git([], nextPatch);
        applied = nextPatch;
        // A compatibility update must leave the entire integration recognizable.
        git(['--reverse', '--check']);
    }
    if (migrate) { await rename(legacy, target); migrated = true; }
    async function ensureDir(path) {
        if (path === host) return;
        await ensureDir(dirname(path));
        if (!await directory(path)) { await mkdir(path); created.push(path); }
    }
    n = 0;
    for (const path of files.keys()) {
        await ensureDir(dirname(path));
        const existing = await stat(path);
        if (existing && !existing.isFile()) throw new Error(`Expected a regular file: ${path}`);
        const backup = existing && join(staging, `old-${n}`);
        if (backup) await rename(path, backup);
        const entry = { path, backup, installed: false };
        undo.push(entry);
        await rename(join(staging, String(n++)), path);
        entry.installed = true;
    }
    console.log(applied ? 'Applied host integration.' : 'Host integration is already installed.');
    console.log(`Installed Pulvis in ${target}`);
} catch (error) {
    try {
        for (const {path, backup, installed} of undo.reverse()) {
            if (installed) await rm(path);
            if (backup) await rename(backup, path);
        }
        for (const path of created.reverse()) await rmdir(path);
        if (migrated) await rename(target, legacy);
        if (applied) git(['--reverse'], applied);
    } catch (recovery) {
        preserveBackup = true;
        throw new AggregateError([error, recovery], `Install rollback failed. Backups: ${staging}`);
    }
    throw error;
} finally {
    if (staging && !preserveBackup) await rm(staging, { recursive: true, force: true });
    await rmdir(lock);
}
